package com.fujie.sumfragment;

import junit.framework.TestCase;

public class MyFragmentTest extends TestCase {

}