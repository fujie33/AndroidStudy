package com.fujie.sumfragment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.util.Log;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Log.i("Aty2" ,"执行onCreate");
        Intent intent=this.getIntent();
        String sum=intent.getStringExtra("sum");
        TextView show_conntent=(TextView)findViewById(R.id.show_conntent);
        show_conntent.setText("A+B="+sum);
    }
    protected void onStart() {
        super.onStart();
        Log.i("Aty2" ,"执行onStart");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("Aty2" ,"执行onRestart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.i("Aty2" ,"执行onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.i("Aty2" ,"onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i("Aty2" ,"执行onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("Aty2" ,"执行onDestroy");
    }

}