package com.fujie.sumfragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.app.Activity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fujie.sumfragment.databinding.FragmentMyBinding;


public class MyFragment extends Fragment {

    FragmentMyBinding v;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.e("LOG", "onCreateView");
        v = FragmentMyBinding.inflate(getLayoutInflater());
        return v.getRoot();
    }


    @Override
    public void onInflate(Activity activity, AttributeSet attrs,
                          Bundle savedInstanceState) {
        Log.e("LOG", "onInflate");
        super.onInflate(activity, attrs, savedInstanceState);
    }

    @Override
    public void onAttach(Activity activity) {
        Log.e("LOG", "onAttach");
        super.onAttach(activity);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.e("LOG", "onCreate");
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Log.e("LOG", "onViewCreated");
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        Log.e("LOG", "onActivityCreated");
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onStart() {
        Log.e("LOG", "onStart");
        super.onStart();
    }

    @Override
    public void onResume() {
        Log.e("LOG", "onResume");
        super.onResume();
    }

    @Override
    public void onPause() {
        Log.e("LOG", "onPause");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.e("LOG", "onStop");

        super.onStop();
    }

    @Override
    public void onDestroyView() {
        Log.e("LOG", "onDestroyView");
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        Log.e("LOG", "onDestroy");
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        Log.e("LOG", "onDetach");
        super.onDetach();
    }

}