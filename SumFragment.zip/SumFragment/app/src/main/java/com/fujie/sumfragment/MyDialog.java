package com.fujie.sumfragment;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import com.fujie.sumfragment.databinding.ActivityDialogBinding;

public class MyDialog extends DialogFragment {
    ActivityDialogBinding binding;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = ActivityDialogBinding.inflate(getLayoutInflater());
        binding.nJump.setOnClickListener(v->{
            Intent i = new Intent(getActivity(),SecondActivity.class);
            i.putExtra("sum",Integer.parseInt(binding.editText3.getText().toString())+
                    Integer.parseInt(binding.editText4.getText().toString()));
//            Log.v("Log","sum");
//            System.out.println();
            startActivity(i);
        });
        return binding.getRoot();
    }
}
